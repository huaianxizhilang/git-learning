package com.ruoyi.jgit.porcelain;

/*
   Copyright 2013, 2014 Dominik Stadler

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
 */

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import org.eclipse.jgit.api.CloneCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.LsRemoteCommand;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.transport.JschConfigSessionFactory;
import org.eclipse.jgit.transport.OpenSshConfig;
import org.eclipse.jgit.transport.SshSessionFactory;
import org.eclipse.jgit.transport.SshTransport;
import org.eclipse.jgit.util.FS;

import java.util.Collection;
import java.util.Map;
import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Simple snippet which shows how to list heads/tags of remote repositories without
 * a local repository
 *
 * @author dominik.stadler at gmx.at
 */
public class ListRemoteRepository {

    private static final String REMOTE_URL = "https://github.com/github/testrepo.git";

    public static void main(String[] args) throws GitAPIException {
        // then clone
        System.out.println("Listing remote repository " + REMOTE_URL);
        Collection<Ref> refs = Git.lsRemoteRepository()
                .setHeads(true)
                .setTags(true)
                .setRemote(REMOTE_URL)
                .call();

        for (Ref ref : refs) {
            System.out.println("Ref: " + ref);
        }

        final Map<String, Ref> map = Git.lsRemoteRepository()
                .setHeads(true)
                .setTags(true)
                .setRemote(REMOTE_URL)
                .callAsMap();

        System.out.println("As map");
        for (Map.Entry<String, Ref> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Ref: " + entry.getValue());
        }

        refs = Git.lsRemoteRepository()
                .setRemote(REMOTE_URL)
                .call();

        System.out.println("All refs");
        for (Ref ref : refs) {
            System.out.println("Ref: " + ref);
        }
    }
}


//本地demo--不配置本地仓库，直接ssh认证----------正确例子
//public class ListRemoteRepository {
//
//    public static void main() throws GitAPIException {
//
//        String remoteRepoPath = "git@gitee.com:jshaxzl/gitee-learning.git"; //git地址
//        String keyPath = "C:\\Users\\19607\\.ssh\\id_rsa.gitee";  //私钥文件
//        SshSessionFactory sshSessionFactory = new JschConfigSessionFactory() {
//            @Override
//            protected void configure(OpenSshConfig.Host host, Session session) {
//                session.setConfig("StrictHostKeyChecking", "no");
//            }
//
//            @Override
//            protected JSch createDefaultJSch(FS fs) throws JSchException {
//                JSch sch = super.createDefaultJSch(fs);
//                sch.addIdentity(keyPath); //添加私钥文件
//                return sch;
//            }
//        };
//
//        //lsremote代码库命令
//        LsRemoteCommand lsRemoteCommand = Git.lsRemoteRepository();
//        // then ls
//        System.out.println("Listing remote repository " + remoteRepoPath);
//        Collection<Ref> refs = lsRemoteCommand
//                .setHeads(true)
//                .setTags(true)
//                .setRemote(remoteRepoPath)
//                .setTransportConfigCallback(transport -> {
//                    SshTransport sshTransport = (SshTransport) transport;
//                    sshTransport.setSshSessionFactory(sshSessionFactory);
//                })
//                .call();
//        System.out.println("sucess");
//        for (Ref ref : refs) {
//            System.out.println("Ref: " + ref);
//        }
//
//        final Map<String, Ref> map = lsRemoteCommand
//                .setHeads(true)
//                .setTags(true)
//                .setRemote(remoteRepoPath)
//                .setTransportConfigCallback(transport -> {
//                    SshTransport sshTransport = (SshTransport) transport;
//                    sshTransport.setSshSessionFactory(sshSessionFactory);
//                })
//                .callAsMap();
//
//        System.out.println("As map");
//        for (Map.Entry<String, Ref> entry : map.entrySet()) {
//            System.out.println("Key: " + entry.getKey() + ", Ref: " + entry.getValue());
//        }
//
//        refs = lsRemoteCommand
//                .setHeads(true)
//                .setTags(true)
//                .setRemote(remoteRepoPath)
//                .setTransportConfigCallback(transport -> {
//                    SshTransport sshTransport = (SshTransport) transport;
//                    sshTransport.setSshSessionFactory(sshSessionFactory);
//                })
//                .call();
//
//        System.out.println("All refs");
//        for (Ref ref : refs) {
//            System.out.println("Ref: " + ref);
//        }
//    }
//}


////本地demo----直接使用本地已有clone完毕的仓库报错----------错误例子
//public class ListRemoteRepository {
//
//
//    public static void main() throws GitAPIException, IOException {
//        // 打开一个已有本地仓库，进行文件添加
//        // 不要借鉴FileRepository Builderopenrepository打开本地已有的git仓库，采用如下方式获取
//        Git git = Git.open(new File("A:\\professional\\idea\\IdeaProjects\\02 ruoyi-vue\\gitutil-test1"));
//        System.out.println("Listing remote repository ");
//        Collection<Ref> refs = git.lsRemoteRepository()
//                .setHeads(true)
//                .setTags(true)
//                .call();
//        for (Ref ref : refs) {
//            System.out.println("Ref: " + ref);
//        }
//        final Map<String, Ref> map = git.lsRemoteRepository()
//                .setHeads(true)
//                .setTags(true)
//                .callAsMap();
//
//        System.out.println("As map");
//        for (Map.Entry<String, Ref> entry : map.entrySet()) {
//            System.out.println("Key: " + entry.getKey() + ", Ref: " + entry.getValue());
//        }
//
//        refs = git.lsRemoteRepository()
//                .call();
//
//        System.out.println("All refs");
//        for (Ref ref : refs) {
//            System.out.println("Ref: " + ref);
//        }
//    }
//}