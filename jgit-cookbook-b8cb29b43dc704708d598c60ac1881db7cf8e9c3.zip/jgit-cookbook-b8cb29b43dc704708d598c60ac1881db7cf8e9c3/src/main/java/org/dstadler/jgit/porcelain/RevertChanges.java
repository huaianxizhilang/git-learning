package org.dstadler.jgit.porcelain;

import org.apache.commons.io.FileUtils;
import org.dstadler.jgit.helper.CookbookHelper;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.Repository;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Simple snippet which shows how to set a modified tracked file back to its state
 * in the most recent commit. This does not make a new commit that reverts a previous commit;
 * this reverts a modified file back to its unmodified state (according to most recent commit)
 *
 * @author JordanMartinez
 */
public class RevertChanges {

    public static void main(String[] args) throws IOException, GitAPIException {
        final File localPath;
        try (Repository repository = CookbookHelper.createNewRepository()) {
            localPath = repository.getWorkTree();

            System.out.println("Listing local branches:");
            try (Git git = new Git(repository)) {
                // set up a file
                String fileName = "temptFile.txt";
                File tempFile = new File(repository.getDirectory().getParentFile(), fileName);
                if(!tempFile.createNewFile()) {
                    throw new IOException("Could not create temporary file " + tempFile);
                }
                Path tempFilePath = tempFile.toPath();

                // write some initial text to it
                String initialText = "Initial Text";
                System.out.println("Writing text [" + initialText + "] to file [" + tempFile.toString() + "]");
                Files.write(tempFilePath, initialText.getBytes());

                // add the file and commit it
                git.add().addFilepattern(fileName).call();
                git.commit().setMessage("Added untracked file " + fileName + "to repo").call();

                // modify the file
                Files.write(tempFilePath, "Some modifications".getBytes(), StandardOpenOption.APPEND);

                // assert that file's text does not equal initialText
                if (initialText.equals(getTextFromFilePath(tempFilePath))) {
                    throw new IllegalStateException("Modified file's text should not equal " +
                            "its original state after modification");
                }

                System.out.println("File now has text [" + getTextFromFilePath(tempFilePath) + "]");

                // revert the changes
                git.checkout().addPath(fileName).call();

                // text should no longer have modifications
                if (!initialText.equals(getTextFromFilePath(tempFilePath))) {
                    throw new IllegalStateException("Reverted file's text should equal its initial text");
                }

                System.out.println("File modifications were reverted. " +
                        "File now has text [" + getTextFromFilePath(tempFilePath) + "]");
            }
        }

        // clean up here to not keep using more and more disk-space for these samples
        FileUtils.deleteDirectory(localPath);
    }

    private static String getTextFromFilePath(Path file) throws IOException {
        byte[] bytes = Files.readAllBytes(file);
        CharBuffer chars = Charset.defaultCharset().decode(ByteBuffer.wrap(bytes));
        return chars.toString();
    }
}
