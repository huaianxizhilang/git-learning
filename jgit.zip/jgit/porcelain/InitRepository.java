package com.ruoyi.jgit.porcelain;

import org.apache.commons.io.FileUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;

import java.io.File;
import java.io.IOException;


/**
 * Simple snippet which shows how to initialize a new repository
 *
 * @author dominik.stadler at gmx.at
 */
public class InitRepository {

    public static void main(String[] args) throws IOException, GitAPIException {
        // method one
        // run the init-call
        File dir = File.createTempFile("gitinit", ".test");
        if(!dir.delete()) {
            throw new IOException("Could not delete file " + dir);
        }

        // The Git-object has a static method to initialize a new repository
        try (Git git = Git.init()
                .setDirectory(dir)
                .call()) {
            System.out.println("Created a new repository at " + git.getRepository().getDirectory());
        }

        // clean up here to not keep using more and more disk-space for these samples
        FileUtils.deleteDirectory(dir);

        dir = File.createTempFile("repoinit", ".test");
        if(!dir.delete()) {
            throw new IOException("Could not delete file " + dir);
        }

        // method two
        // you can also create a Repository-object directly from the
        try (Repository repository = FileRepositoryBuilder.create(new File(dir.getAbsolutePath(), ".git"))) {
            System.out.println("Created a new repository at " + repository.getDirectory());
        }

        // clean up here to not keep using more and more disk-space for these samples
        FileUtils.deleteDirectory(dir);
    }
}
