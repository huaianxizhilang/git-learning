package com.ruoyi.jgit.porcelain;

/*
   Copyright 2013, 2014 Dominik Stadler

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
 */

import com.ruoyi.jgit.helper.CookbookHelper ;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.ObjectReader;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.treewalk.CanonicalTreeParser;

import java.io.File;
import java.io.IOException;
import java.util.List;


/**
 * Snippet which shows how to show diffs between two commits.
 *
 * @author dominik.stadler at gmx.at
 */
public class ShowChangedFilesBetweenCommits {

    public static void main(String[] args) throws IOException, GitAPIException {
        try (Repository repository = CookbookHelper.openJGitCookbookRepository()) {
            // The {tree} will return the underlying tree-id instead of the commit-id itself!
            // For a description of what the carets do see e.g. http://www.paulboxley.com/blog/2011/06/git-caret-and-tilde
            // This means we are selecting the parent of the parent of the parent of the parent of current HEAD and
            // take the tree-ish of it
            // head 当前提交 HEAD^{tree}代表父提交
            ObjectId oldHead = repository.resolve("HEAD^^^^{tree}");
            ObjectId head = repository.resolve("HEAD^{tree}");

            System.out.println("Printing diff between tree: " + oldHead + " and " + head);

            // prepare the two iterators to compute the diff between
    		try (ObjectReader reader = repository.newObjectReader()) {
        		CanonicalTreeParser oldTreeIter = new CanonicalTreeParser();
        		oldTreeIter.reset(reader, oldHead);
        		CanonicalTreeParser newTreeIter = new CanonicalTreeParser();
        		newTreeIter.reset(reader, head);

        		// finally get the list of changed files
        		try (Git git = new Git(repository)) {
                    List<DiffEntry> diffs= git.diff()
            		                    .setNewTree(newTreeIter)
            		                    .setOldTree(oldTreeIter)
            		                    .call();
                    for (DiffEntry entry : diffs) {
                        System.out.println("old: " + entry.getOldPath() +
                                ", new: " + entry.getNewPath() +
                                ", entry: " + entry);
                    }
        		}
    		}
        }

        System.out.println("Done");
    }


//    //本地demo
//    public static void main() throws IOException, GitAPIException {
//            // 打开一个已有本地仓库，进行文件添加
//            // 不要借鉴FileRepository Builderopenrepository打开本地已有的git仓库，采用如下方式获取
//            Git git = Git.open(new File("A:\\professional\\idea\\IdeaProjects\\02 ruoyi-vue\\gitutil-test1"));
//            Repository repository = git.getRepository();
//            // The {tree} will return the underlying tree-id instead of the commit-id itself!
//            // For a description of what the carets do see e.g. http://www.paulboxley.com/blog/2011/06/git-caret-and-tilde
//            // This means we are selecting the parent of the parent of the parent of the parent of current HEAD and
//            // take the tree-ish of it
//            // head 当前提交 HEAD^{tree}代表父提交
//            ObjectId oldHead = repository.resolve("HEAD^^{tree}");
//            ObjectId head = repository.resolve("HEAD^{tree}");
//            System.out.println("Printing diff between tree: " + oldHead + " and " + head);
//            // prepare the two iterators to compute the diff between
//            try (ObjectReader reader = repository.newObjectReader()) {
//                CanonicalTreeParser oldTreeIter = new CanonicalTreeParser();
//                oldTreeIter.reset(reader, oldHead);
//                CanonicalTreeParser newTreeIter = new CanonicalTreeParser();
//                newTreeIter.reset(reader, head);
//
//                // finally get the list of changed files
//                try (Git git2 = new Git(repository)) {
//                    List<DiffEntry> diffs= git2.diff()
//                            .setNewTree(newTreeIter)
//                            .setOldTree(oldTreeIter)
//                            .call();
//                    for (DiffEntry entry : diffs) {
//                        System.out.println("old: " + entry.getOldPath() +
//                                ", new: " + entry.getNewPath() +
//                                ", entry: " + entry);
//                    }
//                }
//            }
//
//        System.out.println("Done");
//    }
}
