package com.ruoyi.jgit.porcelain;

import java.io.File;
import java.io.IOException;

import org.eclipse.jgit.api.CloneCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.lib.StoredConfig;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;
import org.eclipse.jgit.transport.JschConfigSessionFactory;
import org.eclipse.jgit.transport.OpenSshConfig;
import org.eclipse.jgit.transport.SshSessionFactory;
import org.eclipse.jgit.transport.SshTransport;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.eclipse.jgit.util.FS;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * git操作工具类
 * @author houjiayin.co
 *
 */
public class GitPullSsh {

    //localRepoPath 为本地文件夹
    //keyPath 私钥文件 path
    //remoteRepoPath 为 ssh git远端仓库地址
    public static void pullssh() throws IOException, GitAPIException {

        String localCodeDir = "A:\\professional\\idea\\IdeaProjects\\02 ruoyi-vue\\gitutil-test2"; //本地文件夹
        String remoteRepoPath = "git@gitee.com:jshaxzl/gitee-learning.git"; //git地址
        String keyPath = "C:\\Users\\19607\\.ssh\\id_rsa.gitee";  //私钥文件

        //ssh session的工厂,用来创建密匙连接
        SshSessionFactory sshSessionFactory = new JschConfigSessionFactory() {
            @Override
            protected void configure(OpenSshConfig.Host host, Session session) {
                session.setConfig("StrictHostKeyChecking", "no");
            }

            @Override
            protected JSch createDefaultJSch(FS fs) throws JSchException {
                JSch sch = super.createDefaultJSch(fs);
                sch.addIdentity(keyPath); //添加私钥文件
                return sch;
            }
        };

        Git git = Git.open(new File(localCodeDir));
//        StoredConfig config = git.getRepository().getConfig();
//        config.setString("remote", "origin", "fetch", "+refs/*:refs/*");
//        config.save();
        git.pull().setRemote(remoteRepoPath).setTransportConfigCallback(transport -> {
            SshTransport sshTransport = (SshTransport) transport;
            sshTransport.setSshSessionFactory(sshSessionFactory);
        }).setRemote("origin").setRemoteBranchName("dev").call();
        System.out.println("success");
        }
}


